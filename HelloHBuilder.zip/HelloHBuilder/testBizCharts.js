
const { Chart, Axis, Geom, Tooltip } = window.BizCharts;
const data = [
	{ year: "1990", value: 3 },
  { year: "1991", value: 3 },
  { year: "1992", value: 4 },
  { year: "1993", value: 3.5 },
  { year: "1994", value: 5 },
  { year: "1995", value: 4.9 },
  { year: "1996", value: 6 },
  { year: "1997", value: 7 },
  { year: "1998", value: 9 },
  { year: "1999", value: 13 },
  { year: "2000", value: 3.5 },
  { year: "2001", value: 5 },
  { year: "2002", value: 4.9 },
  { year: "2003", value: 6 },
  { year: "2004", value: 7 },
  { year: "2005", value: 9 },
  { year: "2006", value: 13 },
  { year: "2007", value: 3.5 },
  { year: "2008", value: 5 },
  { year: "2009", value: 4.9 },
  { year: "2010", value: 6 },
  { year: "2011", value: 7 },
  { year: "2012", value: 9 },
  { year: "2013", value: 13 },
  { year: "2014", value: 3.5 },
  { year: "2015", value: 5 },
  { year: "2016", value: 4.9 },
  { year: "2017", value: 6 },
  { year: "2018", value: 7 },
  { year: "2019", value: 9 },
  { year: "2020", value: 13 }
];
const cols = {
  'value': { 
  	min: 0,
  	alias:'值'
  },
  'year': {
  	range: [ 0 , 1],
  	alias:'年份',
  	tickCount:10
  	//ticks: [1990, 1995, 2000, 2005,2010,2015,2020], // 用于指定坐标轴上刻度点的文本信息，当用户设置了 ticks 就会按照 ticks 的个数和文本来显示。
    //tickInterval: 1 // 用于指定坐标轴各个标度点的间距，是原始数据之间的间距差值，tickCount 和 tickInterval 不可以同时声明。
		//tickCount: 8,
  }
};



const title = {
  autoRotate: true, // 是否需要自动旋转，默认为 true
  offset: 50, // 设置标题 title 距离坐标轴线的距离
  textStyle: {
    fontSize: '12',
    textAlign: 'center',
    fill: '#999',
    fontWeight: 'bold',
  }, // 坐标轴文本属性配置
  position: 'end' // 标题的位置，**新增**
}

//可配置样式
const tickLine = {
  lineWidth: 1, // 刻度线宽
  stroke: '#ccc', // 刻度线的颜色
  length: 5, // 刻度线的长度, **原来的属性为 line**,可以通过将值设置为负数来改变其在轴上的方向
}

ReactDOM.render((
  <Chart height={400} width={600} data={data} scale={cols} forceFit={false}>
    <Axis name="year" title={title}  label = {{
    rotate:  90
}}/>
    <Axis name="value" title={title}/>
    <Tooltip crosshairs={{type : "y"}}/>
    <Geom type="line" position="year*value" size={2}/>
    <Geom type='point' position="year*value" size={4} shape={'circle'} style={{ stroke: '#fff', lineWidth: 1}} />
  </Chart>
), document.getElementById("mountNode"));
    